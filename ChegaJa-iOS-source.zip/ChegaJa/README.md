# ChegaJá — iOS

Aplicativo nativo em SwiftUI para planejar viagens de ônibus na Região Metropolitana do Recife.

## O que já está criado

- Mapa nativo com Apple MapKit e localização do usuário.
- Paradas próximas, seleção de parada e próximas saídas.
- Busca de destino por endereço, local ou ponto de referência.
- Rota multimodal apresentada em passos: caminhada até a parada, linha e descida.
- Estado claro dos dados: horários programados versus tempo real.
- Ícone e identidade do ChegaJá.

## Fonte de dados gratuita

A fonte operacional é o GTFS oficial do Grande Recife:

- Página: https://www.granderecife.pe.gov.br/transporte/gtfs/
- Feed: https://www.granderecife.pe.gov.br/gtfs/gtfs.zip

O feed contém linhas, mais de 7 mil paradas, itinerários, viagens e horários. Ele não publica GTFS-Realtime aberto no momento. Por isso, esta versão mostra **horários programados** e não os chama de rastreamento ao vivo.

## Para colocar em produção

1. Hospede o backend de importação em uma instância própria.
2. Baixe e valide o GTFS diariamente usando ETag/Last-Modified.
3. Carregue-o em PostgreSQL + PostGIS.
4. Rode OpenTripPlanner com o GTFS e OpenStreetMap para produzir rotas de caminhada, ônibus e metrô.
5. Configure `TransitRepository` no iOS para chamar sua API.
6. Quando o Grande Recife publicar GTFS-Realtime autorizado, conecte VehiclePositions e TripUpdates ao backend. Só então habilite “ao vivo”.

## Atribuição

Dados de transporte: Grande Recife Consórcio de Transporte Metropolitano.
Dados de ruas: © OpenStreetMap contributors, ODbL.

## Abrir no Xcode

O projeto é descrito em `project.yml`. Com XcodeGen instalado no Mac, execute `xcodegen generate`, abra `ChegaJa.xcodeproj`, escolha um simulador iOS 17+ e execute.
