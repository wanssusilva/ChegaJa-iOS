#!/usr/bin/env python3
"""Download/validate Grande Recife GTFS safely for a future PostGIS importer."""
from pathlib import Path
from zipfile import ZipFile
from urllib.request import urlopen

FEED = "https://www.granderecife.pe.gov.br/gtfs/gtfs.zip"
REQUIRED = {"stops.txt", "routes.txt", "trips.txt", "stop_times.txt", "shapes.txt"}
out = Path(__file__).resolve().parents[1] / "data" / "gtfs.zip"
out.parent.mkdir(exist_ok=True)

with urlopen(FEED, timeout=60) as response:
    body = response.read()
out.write_bytes(body)
with ZipFile(out) as z:
    missing = REQUIRED - set(z.namelist())
    if missing:
        raise RuntimeError(f"GTFS inválido; faltam: {', '.join(sorted(missing))}")
    print(f"GTFS válido: {len(z.namelist())} arquivos em {out}")
