import SwiftUI
import MapKit
import CoreLocation

@MainActor
final class AppState: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var position = MapCameraPosition.region(.init(center: .init(latitude: -8.0522, longitude: -34.8813), span: .init(latitudeDelta: 0.045, longitudeDelta: 0.045)))
    @Published var userCoordinate: CLLocationCoordinate2D?
    @Published var stops: [Stop] = []
    @Published var selectedStop: Stop?
    @Published var destination: CLLocationCoordinate2D?
    @Published var tripPlan: TripPlan?
    @Published var isPlanning = false
    @Published var dataMode: TransitDataMode = .schedule
    @Published var errorMessage: String?

    private let manager = CLLocationManager()
    private let repository: TransitRepository = DemoTransitRepository()

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
    }

    func bootstrap() async {
        manager.requestWhenInUseAuthorization()
        if let coordinate = userCoordinate { await loadStops(around: coordinate) }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        guard manager.authorizationStatus == .authorizedWhenInUse || manager.authorizationStatus == .authorizedAlways else { return }
        manager.startUpdatingLocation()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let coordinate = locations.last?.coordinate else { return }
        userCoordinate = coordinate
        position = .region(.init(center: coordinate, span: .init(latitudeDelta: 0.018, longitudeDelta: 0.018)))
        manager.stopUpdatingLocation()
        Task { await loadStops(around: coordinate) }
    }

    func loadStops(around coordinate: CLLocationCoordinate2D) async {
        do { stops = try await repository.nearbyStops(at: coordinate, limit: 8) }
        catch { errorMessage = "Não foi possível carregar as paradas." }
    }

    func select(_ stop: Stop) { selectedStop = stop }

    func defineDestination(_ coordinate: CLLocationCoordinate2D) {
        destination = coordinate
        Task { await makePlan() }
    }

    func makePlan() async {
        guard let start = userCoordinate, let end = destination else { return }
        isPlanning = true
        defer { isPlanning = false }
        do { tripPlan = try await repository.planTrip(from: start, to: end) }
        catch { errorMessage = "Não foi possível criar esta rota." }
    }
}
