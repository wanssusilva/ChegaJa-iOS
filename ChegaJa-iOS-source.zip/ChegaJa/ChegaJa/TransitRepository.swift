import Foundation
import CoreLocation

protocol TransitRepository {
    func nearbyStops(at location: CLLocationCoordinate2D, limit: Int) async throws -> [Stop]
    func arrivals(for stop: Stop, at date: Date) async throws -> [Arrival]
    func planTrip(from origin: CLLocationCoordinate2D, to destination: CLLocationCoordinate2D) async throws -> [TripPlan]
}

/// Development repository. Replace its data source with the ChegaJa backend after GTFS import.
final class DemoTransitRepository: TransitRepository {
    private let routes = [
        Route(id: "040", shortName: "040", longName: "CDU / Caxangá / Boa Viagem", colorHex: "155EEF"),
        Route(id: "1983", shortName: "1983", longName: "Rio Doce / Derby", colorHex: "12B76A"),
        Route(id: "1906", shortName: "1906", longName: "Piedade / Rio Doce", colorHex: "F79009")
    ]

    func nearbyStops(at location: CLLocationCoordinate2D, limit: Int = 6) async throws -> [Stop] {
        let offsets: [(Double, Double, String)] = [
            (0.0011, 0.0005, "Av. Presidente Kennedy, 210"),
            (-0.0016, 0.0011, "R. do Amparo, 88"),
            (0.0022, -0.0019, "Av. Getúlio Vargas, 401"),
            (-0.0025, -0.0010, "Estrada do Bonsucesso, 77")
        ]
        return offsets.prefix(limit).enumerated().map { index, offset in
            let c = Stop.Coordinate(latitude: location.latitude + offset.0, longitude: location.longitude + offset.1)
            let distance = CLLocation(latitude: location.latitude, longitude: location.longitude)
                .distance(from: CLLocation(latitude: c.latitude, longitude: c.longitude))
            return Stop(id: "demo-stop-\(index)", name: offset.2, coordinate: c, distance: distance, routes: [routes[index % routes.count], routes[(index + 1) % routes.count]])
        }
    }

    func arrivals(for stop: Stop, at date: Date = .now) async throws -> [Arrival] {
        stop.routes.enumerated().map { index, route in
            Arrival(route: route, minutes: [4, 11, 18][index % 3], isRealtime: false)
        }
    }

    func planTrip(from origin: CLLocationCoordinate2D, to destination: CLLocationCoordinate2D) async throws -> [TripPlan] {
        let nearby = try await nearbyStops(at: origin, limit: 2)
        guard let start = nearby.first, let end = nearby.last else { throw URLError(.badServerResponse) }
        return TripPlan(departureStop: start, route: routes[0], arrivalStop: end, walkToStopMinutes: 5, rideMinutes: 23, nextDeparture: .now.addingTimeInterval(8 * 60), isRealtime: false)
    }
}
