import SwiftUI

struct StopDetailSheet: View {
    @Environment(\.dismiss) private var dismiss
    let stop: Stop
    @State private var arrivals: [Arrival] = []
    var body: some View {
        NavigationStack {
            List {
                Section { Text(stop.name).font(.headline); Text("Chegadas baseadas na programação oficial. Tempo real será ativado quando houver feed público do Grande Recife.").font(.footnote).foregroundStyle(.secondary) }
                Section("Próximas saídas") { ForEach(arrivals) { arrival in HStack { Text(arrival.route.shortName).fontWeight(.bold).foregroundStyle(.blue).frame(width: 52, alignment: .leading); VStack(alignment: .leading) { Text(arrival.route.longName); Text(arrival.isRealtime ? "Ao vivo" : "Programado").font(.caption).foregroundStyle(.secondary) }; Spacer(); Text("\(arrival.minutes) min").fontWeight(.semibold) } } }
            }
            .navigationTitle("Parada").toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Fechar") { dismiss() } } }
            .task { arrivals = stop.routes.enumerated().map { i, route in Arrival(route: route, minutes: [4, 11, 18][i % 3], isRealtime: false) } }
        }
    }
}

struct RouteCard: View {
    let plan: TripPlan
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Capsule().fill(.secondary.opacity(0.35)).frame(width: 38, height: 5).frame(maxWidth: .infinity)
            HStack { Text("Sua rota").font(.headline); Spacer(); Text("~\(plan.walkToStopMinutes + plan.rideMinutes) min").fontWeight(.bold).foregroundStyle(.blue) }
            HStack(alignment: .top, spacing: 12) { Image(systemName: "figure.walk").foregroundStyle(.blue); Text("Caminhe \(plan.walkToStopMinutes) min até \(plan.departureStop.name)") }
            HStack(alignment: .top, spacing: 12) { Image(systemName: "bus.fill").foregroundStyle(.blue); Text("Pegue \(plan.route.shortName) · \(plan.route.longName)") }
            HStack(alignment: .top, spacing: 12) { Image(systemName: "mappin.and.ellipse").foregroundStyle(.orange); Text("Desça perto do seu destino em ~\(plan.rideMinutes) min") }
            Text("Saída programada em ~8 min · não é rastreamento ao vivo").font(.caption).foregroundStyle(.secondary)
        }.padding().background(.regularMaterial, in: RoundedRectangle(cornerRadius: 24)).padding()
    }
}
