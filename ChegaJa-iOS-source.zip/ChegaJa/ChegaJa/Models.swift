import Foundation
import CoreLocation

struct Stop: Identifiable, Codable, Hashable {
    let id: String
    let name: String
    let coordinate: Coordinate
    var distance: CLLocationDistance?
    var routes: [Route]

    struct Coordinate: Codable, Hashable {
        let latitude: Double
        let longitude: Double
        var clLocation: CLLocationCoordinate2D { .init(latitude: latitude, longitude: longitude) }
    }
}

struct Route: Identifiable, Codable, Hashable {
    let id: String
    let shortName: String
    let longName: String
    let colorHex: String?
}

struct Arrival: Identifiable, Hashable {
    let id = UUID()
    let route: Route
    let minutes: Int
    let isRealtime: Bool
}

struct TripPlan: Identifiable {
    let id = UUID()
    let departureStop: Stop
    let route: Route
    let arrivalStop: Stop
    let walkToStopMinutes: Int
    let rideMinutes: Int
    let nextDeparture: Date
    let isRealtime: Bool
}

enum TransitDataMode: Equatable {
    case schedule
    case realtime

    var bannerText: String {
        switch self {
        case .schedule: return "Horários programados pelo Grande Recife"
        case .realtime: return "Atualizações em tempo real disponíveis"
        }
    }
}
