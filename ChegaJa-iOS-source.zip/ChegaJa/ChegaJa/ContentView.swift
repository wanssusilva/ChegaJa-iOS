import SwiftUI
import MapKit

struct ContentView: View {
    @EnvironmentObject private var app: AppState
    @State private var showingSearch = false
    @State private var showStopSheet = false

    var body: some View {
        ZStack(alignment: .bottom) {
            Map(position: $app.position, interactionModes: .all) {
                UserAnnotation()
                ForEach(app.stops) { stop in
                    Annotation(stop.name, coordinate: stop.coordinate.clLocation, anchor: .bottom) {
                        StopMarker(selected: app.selectedStop?.id == stop.id)
                            .onTapGesture { app.select(stop); showStopSheet = true }
                    }
                }
                if let destination = app.destination {
                    Marker("Destino", coordinate: destination).tint(.orange)
                }
            }
            .mapStyle(.standard(elevation: .realistic, emphasis: .automatic, pointsOfInterest: .excludingAll))
            .overlay(alignment: .top) { topBar }
            .overlay(alignment: .bottomTrailing) { locateButton }

            if let plan = app.tripPlan { RouteCard(plan: plan) }
            else { nearbyCard }
        }
        .sheet(isPresented: $showingSearch) { DestinationSearchSheet() }
        .sheet(isPresented: $showStopSheet) {
            if let stop = app.selectedStop { StopDetailSheet(stop: stop) }
        }
        .alert("ChegaJá", isPresented: .constant(app.errorMessage != nil), actions: { Button("OK") { app.errorMessage = nil } }, message: { Text(app.errorMessage ?? "") })
    }

    private var topBar: some View {
        HStack(spacing: 10) {
            Button { showingSearch = true } label: {
                HStack { Image(systemName: "magnifyingglass"); Text("Para onde você vai?").fontWeight(.medium); Spacer() }
                    .padding(14).background(.ultraThinMaterial, in: Capsule())
            }
            .buttonStyle(.plain)
            Button { } label: { Image(systemName: "bell").padding(13).background(.ultraThinMaterial, in: Circle()) }
        }
        .padding(.horizontal).padding(.top, 8)
    }

    private var nearbyCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            Capsule().fill(.secondary.opacity(0.35)).frame(width: 38, height: 5).frame(maxWidth: .infinity)
            Text("Paradas perto de você").font(.headline)
            Text(app.dataMode.bannerText).font(.caption).foregroundStyle(.secondary)
            if let closest = app.stops.first {
                Button { app.select(closest); showStopSheet = true } label: {
                    HStack { Image(systemName: "bus.fill").foregroundStyle(.blue); VStack(alignment: .leading) { Text(closest.name).fontWeight(.semibold); Text("\(Int(closest.distance ?? 0)) m · \(closest.routes.map(\.shortName).joined(separator: " · "))").font(.caption).foregroundStyle(.secondary) }; Spacer(); Image(systemName: "chevron.right") }
                }.buttonStyle(.plain)
            } else { ProgressView("Encontrando paradas…") }
        }
        .padding().background(.regularMaterial, in: RoundedRectangle(cornerRadius: 24)).padding()
    }

    private var locateButton: some View {
        Button { if let c = app.userCoordinate { app.position = .region(.init(center: c, span: .init(latitudeDelta: 0.018, longitudeDelta: 0.018))) } } label: {
            Image(systemName: "location.fill").padding(14).background(.thinMaterial, in: Circle())
        }.padding(.trailing, 16).padding(.bottom, app.tripPlan == nil ? 205 : 285)
    }
}

private struct StopMarker: View {
    let selected: Bool
    var body: some View { Image(systemName: "bus.fill").font(.caption.bold()).foregroundStyle(.white).padding(8).background(selected ? .orange : .blue, in: Circle()).shadow(radius: 3) }
}

private struct DestinationSearchSheet: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var app: AppState
    @State private var query = ""
    @State private var results: [MKMapItem] = []
    var body: some View {
        NavigationStack {
            List(results, id: \.self) { item in
                Button { if let coordinate = item.placemark.location?.coordinate { app.defineDestination(coordinate); dismiss() } } label: { VStack(alignment: .leading) { Text(item.name ?? "Destino"); Text(item.placemark.title ?? "").font(.caption).foregroundStyle(.secondary) } }
            }
            .overlay { if results.isEmpty { ContentUnavailableView("Escolha seu destino", systemImage: "mappin.and.ellipse", description: Text("Digite um endereço, local ou ponto de referência.")) } }
            .searchable(text: $query, prompt: "Ex.: Marco Zero")
            .onChange(of: query) { _, value in Task { results = (try? await MKLocalSearch(request: .init(naturalLanguageQuery: value)).start())?.mapItems ?? [] } }
            .navigationTitle("Destino").toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Fechar") { dismiss() } } }
        }
    }
}
